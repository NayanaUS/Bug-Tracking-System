<html>    
    <head>    
        <title>Registration Form</title>    
    </head>    
    <body style="background-image:url(back.jpg);">    
        <link href = "deptregistration.css" type = "text/css" rel = "stylesheet" />
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 
		<ul>
		<a href="../admin15.php" style="float:right; text-decoration:none;">Back to homepage</a>   
		</ul>
		<h2 style="color:black; margin-left:145px;">Department</h2>    
        <form name = "form1" action="deptmodified.php" method="post"  enctype = "multipart/form-data" style="margin-left:35rem;">  
            <div class = "container" style="background-color:lightblue; padding:20px; width:20rem;" >
                <div class = "form_group" style="margin-left:35px;">
                    <br>
                    <label style="color:black;">Dept No</label>
                    <br>
                    <input type = "text" name = "Dept_No" required />    
                </div>
                <div class = "form_group" style="margin-left:35px;">
                    <br>
                    <label  style="color:black;">Dept Name</label>
                    <br>
                    <input type = "text" name = "Dept_Name" value = "" required />    
                </div>    
                <div class = "form_group" style="margin-left:35px;">
                    <br>
                    <label  style="color:black;">Dept Loc</label>
                    <br>
                    <input type = "text" name = "Dept_Loc" value = "" required />
                </div>
				<div class = "form_group" style="margin-left:90px;">    
                    <input type = "submit" value = "submit"/>    
                </div>
				<div class = "form_group"  style="margin-left:95px;">    
                    <input type = "reset" value = "reset"/>    
                </div>
                
                </div>
         
				
				    
                   
               
        </form>    
    </body>    
</html>    