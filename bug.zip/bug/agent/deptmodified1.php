<?php    
include "../connection.php";
    
    
$sql = "select * from department";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body style="background-image:url(back.jpg);">    
		<link href = "deptregistration.css" type = "text/css" rel = "stylesheet" />  
	    <link href = "../style.css" type = "text/css" rel = "stylesheet" /> 
		<ul>
			<li style="float:right;"><a href="../admin15.php"> Back to homepage</a></li>
		</ul>		
		<h1 style="color:black;"><center>Department Data</center></h1>
		
		<table width = "100%" border = "5" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Dept No</td>    
                <td>Dept Name</td>    
                <td>Dept Loc</td>    
                
                <td colspan = "2">Action</td>    
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td>  
					<?php echo $row->Dept_No;?>  
				</td>  
				<td>  
					<?php echo $row->Dept_Name;?>  
				</td>  
				<td>  
					<?php echo $row->Dept_Loc;?>  
				</td>  
				 
				<td> <a href="deptdelete.php?id=<?php echo $row->Dept_No;?>" onclick="return confirm('Are You Sure')">Delete    
				</a>
				</td>  
			</tr>  
		<?php } ?>  			
        </table>   		
    </body>    
</html>