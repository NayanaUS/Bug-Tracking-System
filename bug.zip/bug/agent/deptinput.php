<?php
		include "../connection.php";
		$ac=$_POST['Dept_No'];
		$an=$_POST['Dept_Name'];
		$d=$_POST['Dept_Loc'];
		
		$query="insert into department(Dept_No,Dept_Name,Dept_Loc) values($ac,'$an','$d')";
		mysqli_query($conn,$query) or die($query."Can't Connect to Query...");
?>