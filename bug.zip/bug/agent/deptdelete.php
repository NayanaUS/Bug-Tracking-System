<?php
include "../connection.php";    
if(isset($_GET['id'])){    
$sql = "delete from department where Dept_No = '".$_GET['id']."'";    
$result = mysqli_query($conn,$sql);    
}
header('Location:deptmodified1.php');
?>