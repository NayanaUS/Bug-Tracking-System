<!DOCTYPE html>
<html>
<head>
<title>Page Title</title>
    <link rel="stylesheet" type="text/css" href="about.css">
</head>
<body style="background-image:url(back.jpg);">
<div style="margin-top:10rem;">
    <h1>BUG TRACKING SYSTEM</h1>
<p>Bug Tracking System is an ideal solution to track the bugs of a product, solution or an application. Bug Tacking System allows individual or groups of developers to keep track of outstanding bugs in their product effectively. This can also be called as Defect Tracking System.</p>
    
<p>The main objective of this system is develop flawless system, which is access real time information from the list of blog bugs given, 24 hours a day 365 days in a year.  Another aim is that manage listed of projects . The another main objective of this system is to manage the list of the defects or bugs in the project and make the project user friendly and bugs free system.</p>
    
<p>This system maintains the products, Bugs and bug Tracking. It has advantage of maintaining bug history it stores all the details of bug and their solutions .
</p>


    
    </div>
</body>
</html>
