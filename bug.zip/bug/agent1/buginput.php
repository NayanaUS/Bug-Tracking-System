<?php
		include "../connection.php";
		$ac=$_POST['Bug_No'];
		$an=$_POST['Bug_Name'];
        $d=$_POST['D_No'];
		$p=$_POST['ECode'];
		$des=$_POST['Description'];
		
		$query="insert into bug_report(Bug_No,Bug_Name,D_No,ECode,Description) values($ac,'$an',$d,$p,'$des')";
		mysqli_query($conn,$query) or die($query."Can't Connect to Query...");
?>