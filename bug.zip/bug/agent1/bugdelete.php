<?php
include "../connection.php";    
if(isset($_GET['id'])){    
$sql = "delete from bug_report where Bug_No = '".$_GET['id']."'";    
$result = mysqli_query($conn,$sql);    
}
header('Location:bugmodified1.php');
?>