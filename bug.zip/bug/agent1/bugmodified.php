<?php    
include "buginput.php";    
        
$sql = "select * from bug_report";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body>    
        <link href = "../style.css" type = "text/css" rel = "stylesheet" />    
		<link href = "bugregistration.css" type = "text/css" rel = "stylesheet" />    
		<table width = "90%" border = "5" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Bug Number</td>    
                <td>Bug Name</td>     
                <td>Department Number</td>    
                <td>Employee Code</td>    
                <td>Description</td> 
                <td colspan = "2">Action</td>    
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td>  
					<?php echo $row->Bug_No;?>  
				</td>  
				<td>  
					<?php echo $row->Bug_Name;?>  
				</td>
                <td>  
					<?php echo $row->D_No;?>  
				</td>
                <td>  
					<?php echo $row->ECode;?>  
				</td>  
				<td>  
					<?php echo $row->Descrption;?>  
				</td>    
				
				<td> <a href="bugdelete.php?id =     
					<?php echo $row->Bug_No;?>" onclick="return confirm('Are You Sure')">Delete    
				</a> 
				</td>  
			</tr>  
		<?php } ?>  			
        </table>
<?php header('Location: bugmodified1.php')?>;   		
    </body>    
</html>