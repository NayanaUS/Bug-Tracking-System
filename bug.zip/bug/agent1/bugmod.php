<?php    
include "../connection.php";
    
    
$sql = "select * from bug_report";    
$result = mysqli_query($conn,$sql);    
?>    
<html>    
    <body style="background-image:url(back.jpg);">    
		<link href = "bugregistration.css" type = "text/css" rel = "stylesheet" />  
	    <link href = "../style.css" type = "text/css" rel = "stylesheet" /> 
		<ul>
			<li style="float:right;"><a href="../admin15.php"> Back to homepage</a></li>
		</ul>		
		<h1 style="color:black;"><center>Bug Report</center></h1>
		
		<table width = "100%" border = "5" cellspacing = "1" cellpadding = "1">    
            <tr>    
                <td>Bug No</td>    
                <td>Bug Name</td>    
                <td>Dept No</td>  
                <td>E Code</td>    
                <td>Description</td> 
                <td>Solution</td>
                
                <td colspan = "2">Action</td>    
            </tr>  
	<?php    
    
		while($row = mysqli_fetch_object($result)){    
    
    
	?>  
			<tr>  
				<td>  
					<?php echo $row->Bug_No;?>  
				</td>  
				<td>  
					<?php echo $row->Bug_Name;?>  
				</td>  
				<td>  
					<?php echo $row->D_No;?>  
				</td>  
				 <td>  
					<?php echo $row->ECode;?>  
				</td>  
				 <td>  
					<?php echo $row->Description;?>  
				</td>  
				 <td>  
					<?php echo $row->Solution;?>  
				</td>  
				 
				<td> <a href="bugdelete.php?id=<?php echo $row->Dept_No;?>" onclick="return confirm('Are You Sure')">Delete    
				</a>
				</td>  
			</tr>  
		<?php } ?>  			
        </table>   		
    </body>    
</html>