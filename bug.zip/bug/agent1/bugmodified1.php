<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<?php    
include "../connection.php";
    
    
$sql = "select * from bug_report";    
$result = mysqli_query($conn,$sql);    
?>    
<html>
    <head><title>Chandana</title></head>
    <body style="background-image:url(back.jpg);">    
		<link href = "bugregistration.css" type = "text/css" rel = "stylesheet" />  
	    <link href = "../style.css" type = "text/css" rel = "stylesheet" /> 
			<a href="../clientad.php" style="float:right; text-decoration:none; color:black;"> Back to homepage</a>		
		<h1 style="color:black;"><center>Bug Data</center></h1>
		
		 <form action="bugmodified1.php" method="post" enctype="multipart/form-data">
      <div class="form-group">
       <table width = "80%" border = "3" cellspacing = "1" cellpadding = "1" style="margin-left:10rem;" >
  <tbody>
    <tr>
      <th scope="row">Bug Name</th>
      <td><input class="form-control" type="text" name="id" placeholder="Enter Bug Name" required></td>
        <th scope="row"><button type="submit" name="submit" style="font-size:20px;">Search</button></th>
    </tr>
    
     
      
  </tbody>
  
</table>
    
     </div>
      </form>
    
      <div class="form-group">
       <table width = "100%" border = "5" cellspacing = "1" cellpadding = "1">
          <?php $con = mysqli_connect("localhost", "root", "", "bug_tracking_system"); 
         $id=$_POST['id'];
        
        $sql="SELECT * FROM `bug_report` WHERE `Bug_Name`='$id'"; 
           $run=mysqli_query($con,$sql);
$data=mysqli_fetch_assoc($run)?> 
           <h2>This is the bug description of <?php echo $data['Bug_Name'];?></h2>
  <tbody>
    <tr>
      <th scope="row">Bug ID</th>
      <th scope="row">Bug Name</th>
      <th scope="row">Description</th>
        <th scope="row">Solution</th>
    </tr>
     <?php
            
    if(isset($_POST['submit']))
        {
        $con = mysqli_connect("localhost", "root", "", "bug_tracking_system"); 
         $id=$_POST['id'];
        
        $sql="SELECT * FROM `bug_report` WHERE `Bug_Name`='$id'";
        $run=mysqli_query($con,$sql);
        
        if(mysqli_num_rows($run)<1)
        {
            echo"<tr><td colspan='11'>Sorry! No records found</td><tr>";
        }
        else
        {   $count=0;
            while($data=mysqli_fetch_assoc($run))
            {
                    $count++;
                ?>
                <tr>

                      <th scope="row"><?php echo $data['Bug_No'];?></th>
                      <th scope="row"><?php echo $data['Bug_Name'];?></th>
                      <th scope="row"><?php echo $data['Description'];?></th>
                      <th scope="row"><?php echo $data['Solution'];?></th>
                </tr>
                <?php
                
                
            }
        }
    }
        ?>
     
  
          </table> 
     </div>
</body>    
</html>