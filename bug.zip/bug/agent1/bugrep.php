<html>    
    <head>    
        <title>Registration Form</title>    
    </head>    
    <body>    
        <link href = "bugregistration.css" type = "text/css" rel = "stylesheet" />
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 
		<ul>
		<li style="float:right;"><a href="../admin15.php">Back to homepage</a></li>    
		</ul>
		<h2>Add Bug</h2>    
        <form name = "form1" action='bugmodified.php' method = 'POST' enctype = "multipart/form-data" >    
            <div class = "container">
				<div class = "form_group">
                    <br>
                    <label>Bug Number</label> 
                    </br>
                    <input type = "text" name = "Bug_No" required />    
                </div>
                <div class = "form_group">
                    <br>
                    <label>Bug Name</label>
                    </br>
                    <input type = "text" name = "Bug_Name" value = "" required />    
                </div>    
                <div class = "form_group">
                    <br>
                    <label>Dept No</label>
                    </br>
                    <input type = "text" name = "D_No" value = "" required />
                </div>
            <div class = "form_group">
                <br>
                    <label>Employee Code</label>
                </br>
                    <input type = "text" name = "ECode" value = "" required />    
                </div>    
                <div class = "form_group">
                    <br>
                    <label>Description</label>
                    </br>
                    <input type = "text" name = "Description" value = "" required />
                </div>
				<div class = "form_group"> 
                    <br>
                    <input type = "submit" value = "submit"/>
                    </br>
                </div>
				<div class = "form_group">
                    <br>
                    <input type = "reset" value = "reset"/>
                    </br>
                </div>
				    
                   
              
            </div>    
        </form>    
    </body>    
</html>    