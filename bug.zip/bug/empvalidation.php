<?php

session_start();

$con = mysqli_connect("localhost","root","","bug_tracking_system");

$code = $_POST['ecode'];
$name = $_POST['user'];
$date = $_POST['dob'];
$qualif = $_POST['qualif'];
$mobileno = $_POST['mobile_no'];
$dno = $_POST['dno'];
$em = $_POST['emailid'];
$pass = $_POST['password'];

$s = "select * from employee where ECode = '$code' && Name = '$name' && DOB = '$date' && Qualification = '$qualif' && Mobile_No = '$mobileno' && D_No = '$dno' && Email_Id = '$em' && Password = '$pass'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

if($num ==1){
    $_SESSION['ecode'] = $code;
    header("location:admin15.php");
}
else{
    header("location:register.php");
}

?>