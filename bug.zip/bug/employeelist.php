<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="shortcut icon" href="avatar.png">
      <link rel="stylesheet" href="employeelist.css">
    
    <title>Employee</title>
  </head>
    <header>
    <div class="menu-toggle" id="hamburger">
            <i class="fas fa-bars"></i>
        </div>
    </header>
  <body>
      <div class="container" style="margin-left:90px;"></div>
          <div class="jumbotron text-center login-box"></div>
        <br>
        <br>
       <h1 style="color: black;"></h1> 
      <p class="lead"></p>
      <hr>
      <form action="employeelist.php" method="post" enctype="multipart/form-data">
      <div class="form-group">
       <table class="table table-striped table-dark">
  <tbody>
    <tr>
      <th scope="row">Employee Name</th>
      <td><input class="form-control" type="text" name="id" placeholder="Enter Employee" required></td>
      </tr> 
  </tbody>
  
</table>
    <button type="submit" class="btn btn-orange" name="submit">Search</button>
     </div>
      </form>
    
      <div class="form-group">
       <table class="table table-bordered table-hover table-dark">
          <?php $con = mysqli_connect("localhost", "root", "", "bug_tracking_system"); 
         $id=$_POST['id'];
        
        $sql="SELECT * FROM `employee_details` WHERE `Ename`='$id'"; 
           $run=mysqli_query($con,$sql);
$data=mysqli_fetch_assoc($run)?> 
  <tbody>
    <tr>
      <th scope="row">Employee Name</th>
      <th scope="row">Employee ID</th>
    </tr>
     <?php
            
    if(isset($_POST['submit']))
        {
        $con = mysqli_connect("localhost", "root", "", "bug_tracking_system"); 
         $id=$_POST['id'];
        
        $sql="SELECT * FROM `employee_details` WHERE `Ename`='$id'";
        $run=mysqli_query($con,$sql);
        
        if(mysqli_num_rows($run)<1)
        {
            echo"<tr><td colspan='11'>Sorry! No records found</td><tr>";
        }
        else
        {   $count=0;
            while($data=mysqli_fetch_assoc($run))
            {
                    $count++;
            
      
      ?>   
                <tr>

                      <th scope="row"><?php echo $data['id'];?></th>
                      <th scope="row"><?php echo $data['Ename'];?></th>
                      <th scope="row"><?php echo $data['Project'];?></th>
                </tr>
       <?php
         }
        }
      
      ?>
          </table>
      </div>
    
      
            <div class="form-group">
            <table>
                <tr>
                <th>Employee ID</th>
                    <th>Employee Name</th>
                </tr>
      
          </table> 
     </div>
  </body>  
    </html>