<?php

session_start();

$con = mysqli_connect("localhost","root","","bug_tracking_system");

$name = $_POST['user'];
$pass = $_POST['password'];

$s = "select * from Client_login where Username = '$name' && Password = '$pass'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

if($num == 1){
    $_SESSION['Username'] = $name;
    header("location:clientad.php");
}
else{
    header("location:index15.php");
}

?>