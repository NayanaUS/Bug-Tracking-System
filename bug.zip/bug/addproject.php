<?php

session_start();
header("location:assignproject.php");

$con = mysqli_connect("localhost","root","","bug_tracking_system");

$bugno = $_POST['bugno'];
$bugname = $_POST['bugname'];
$user =  $_POST['username'];

$s = "select * from assign_project where User_name = '$user'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

if($num == 1){
    header("location:assignproject.php");
    echo" You have already added this report";
}
else{
    $reg = "insert into assign_project(Bug_No,Bug_Name,User_Name) values ('$bugno','$bugname','$user')";
    mysqli_query($con,$reg);
    echo" Reported successfully"; 
    header("location:reported.php");
}

?>