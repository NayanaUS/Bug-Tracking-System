<!DOCTYPE html>
<html lang="en">
<head>
<title>Bug List</title>
<link rel="stylesheet" type="text/css" href="clientad.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="topnav">
  
    <a href="assignproject.php">Assign Project</a>
    <div class="dropdown">
    <button class="dropbtn">Bug Report
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="agent1/bugmodified1.php">report bugs</a>
        </div>
    </div>
    </div>
<div style="margin-left:40rem; margin-top:10rem; color:white; font-family:sans seriff; font-size:30px;">
    <h2>The list of Bugs</h2>

<ul>
  <li style="color:red;">Incorrect Calculation</li>
  <li style="color:violet;">Functional Errors</li>
  <li style="color:orange;">Error Handling Errors</li>
  <li style="color:white;">Acknowledgment Message Errors</li>
    <li style="color:black;">Missing Command Errors</li>
    <li style="color:indigo;">Syntactic Errors</li>
    <li style="color:pink;">Control Flow Errors</li>
    
</ul>   
</div>

        </body>
    </html>
