<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<link rel="stylesheet" type="text/css" href="admin15.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>
<div class="topnav">
  <a href="emp.php">Employee</a>
   <div class="dropdown">
    <button class="dropbtn">Department
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="agent/dept.php">Add Department</a>
      <a href="agent/deptmodified1.php">view Department</a>
	  </div>
    </div>
	   <div class="dropdown">
    <button class="dropbtn">Bug Report
      <i class="fa fa-caret-down"></i>
    </button>
    <div class="dropdown-content">
      <a href="agent1/bugmod.php">report bugs</a>
	  </div>
	  </div>
											 
												 
	  </div>




</body>
</html>
