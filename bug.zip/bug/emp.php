<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<?php    
include "connection.php";
    
    
$sql = "select * from employee_details";    
$result = mysqli_query($conn,$sql);    
?>    
<html>
    <head><title>Chandana</title></head>
    <body style="background-image:url(back.jpg);">    
		<link href = "bugregistration.css" type = "text/css" rel = "stylesheet" />  
	    <link href = "../style.css" type = "text/css" rel = "stylesheet" /> 

		<h1 style="color:black;"><center>Employee Data</center></h1>
		
		 <form action="emp.php" method="post" enctype="multipart/form-data">
      <div class="form-group">
       <table width = "80%" border = "3" cellspacing = "1" cellpadding = "1" style="margin-left:10rem;" >
  <tbody>
    <tr>
      <th scope="row">Employee Name</th>
      <td><input class="form-control" type="text" name="id" placeholder="Enter Employee Name" required></td>
        <th scope="row"><button type="submit" name="submit" style="font-size:20px;">Search</button></th>
    </tr>
    
     
      
  </tbody>
  
</table>
    
     </div>
      </form>
    
      <div class="form-group">
       <table width = "100%" border = "5" cellspacing = "1" cellpadding = "1">
          <?php $con = mysqli_connect("localhost", "root", "", "bug_tracking_system"); 
         $id=$_POST['id'];
        
        $sql="SELECT * FROM `employee_details` WHERE `Ename`='$id'"; 
           $run=mysqli_query($con,$sql);
$data=mysqli_fetch_assoc($run)?> 
           <h2>This is the bug description of <?php echo $data['Ename'];?></h2>
  <tbody>
    <tr>
      <th scope="row">ID</th>
      <th scope="row">Name</th>
      <th scope="row">Project</th>
    </tr>
     <?php
            
    if(isset($_POST['submit']))
        {
        $con = mysqli_connect("localhost", "root", "", "bug_tracking_system"); 
         $id=$_POST['id'];
        
        $sql="SELECT * FROM `employee_details` WHERE `Ename`='$id'";
        $run=mysqli_query($con,$sql);
        
        if(mysqli_num_rows($run)<1)
        {
            echo"<tr><td colspan='11'>Sorry! No records found</td><tr>";
        }
        else
        {   $count=0;
            while($data=mysqli_fetch_assoc($run))
            {
                    $count++;
                ?>
                <tr>

                      <th scope="row"><?php echo $data['id'];?></th>
                      <th scope="row"><?php echo $data['Ename'];?></th>
                      <th scope="row"><?php echo $data['Project'];?></th>
                </tr>
                <?php
                
                
            }
        }
    }
        ?>
     
  
          </table> 
     </div>
</body>    
</html>