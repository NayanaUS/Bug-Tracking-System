
<html>
<head>
	<title>Thanks</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
	</head>
<body style="background-image:url(back.jpg);">
<h1 style="margin-top:20rem; font-size:35px;" >Your report has Been submitted successfully!!</h1>
    <h2 style="margin-left:43rem;"><a>Please <a href="index15.php" style="text-decoration:none;">Logout</a></a></h2>

</body>

</html>