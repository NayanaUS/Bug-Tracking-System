
<html>
<head>
	<title>Assign Project</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
	</head>
<body style="background-image:url(back.jpg);">
	<div class="loginbox">
	
		<div class="form">
		<form action="addproject.php" class="Login-form" method="post">
			<h1>Please Assign Project</h1>
			<p>Enter Bug Number</p>
			<input type="text" name="bugno" placeholder="Enter Bug No." required>
			<p>Enter Bug Name</p>
			<input type="text" name="bugname" placeholder="Enter Bug Name" required>
			<p>Enter your Username</p>
			<input type="text" name="username" placeholder="Enter Username" required>
			<input type="submit" name="submit" value="Submit" >
			</form>
		</div>
	</div>


</body>

</html>