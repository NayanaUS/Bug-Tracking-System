<html>
<head>
	<title>Login and Register Form Design</title>
	<link rel="stylesheet" type="text/css" href="rstyle.css">
	</head>
<body>
<div>
<div class="registerbox">
<form action="empvalidation.php" class="Login-form" method="post" >
			<h1>Employee Login</h1>
			<p>ECode</p>
			<input type="text" name="ecode" placeholder="Employee Id" required>
			<p>FName</p>
			<input type="text" name="user" placeholder="Enter Name" required>
			<p>DOB</p>
			<input type="text" name="dob" placeholder="Enter Date Of Birth" required>
			<p>Qualification</p>
			<input type="text" name="qualif" placeholder="Enter Qualification" required>
			<p>Mobile_No</p>
			<input type="text" name="mobile_no" placeholder="Enter Mobile_No" required>
			<p>D_No</p>
			<input type="text" name="dno" placeholder="Enter Department number" required>
			<p>Email_Id</p>
			<input type="text" name="emailid" placeholder="Enter Email" required>
			<p>Password</p>
			<input type="password" name="password" placeholder="Enter Password" required>
			<input type="submit" name="submit" value="Login">
			 </form>
		</div>
		</div>
		</body>

</html>