<?php

session_start();
header("location:index15.php");

$con = mysqli_connect("localhost","root","","bug_tracking_system");

$name = $_POST['user'];
$pass = $_POST['password'];

$s = "select * from Client_login where Username = '$name'";

$result = mysqli_query($con,$s);

$num = mysqli_num_rows($result);

if($num == 1){
    header("location:index15.php");
    echo" Username already taken";
}
else{
    $reg = "insert into Client_login(Username,Password) values ('$name','$pass')";
    mysqli_query($con,$reg);
    echo" Registeration Successful";    
}

?>