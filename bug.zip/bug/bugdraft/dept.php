<html>    
    <head>    
        <title>Registration Form</title>    
    </head>    
    <body>    
        <link href = "deptregistration.css" type = "text/css" rel = "stylesheet" />
		<link href = "../style.css" type = "text/css" rel = "stylesheet" /> 
		<ul>
		<li style="float:right;"><a href="../admin15.php">Back to homepage</a></li>    
		</ul>
		<h2>Department</h2>    
        <form name = "form1" action='deptmodified.php' method = 'POST' enctype = "multipart/form-data" >    
            <div class = "container">
				<div class = "form_group">
                    <br>
                    <label>Dept No</label>
                    </br>
                    <input type = "text" name = "Dept_No" required />    
                </div>
                <div class = "form_group" style="margin-left:40rem;">
                    <br>
                    <label>Dept Name</label>
                    </br>
                    <input type = "text" name = "Dept_Name" value = "" required />    
                </div>    
                <div class = "form_group">
                    <br>
                    <label>Dept Loc</label>
                    </br>
                    <input type = "text" name = "Dept_Loc" value = "" required />
                </div>
				<div class = "form_group">    
                    <input type = "submit" value = "submit"/>    
                </div>
				<div class = "form_group">    
                    <input type = "reset" value = "reset"/>    
                </div>
				    
                   
              
            </div>    
        </form>    
    </body>    
</html>    