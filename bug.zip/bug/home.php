<!DOCTYPE html>
<html lang="en">
<head>
<title>Page Title</title>
<link rel="stylesheet" type="text/css" href="hstyle15.css">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
</head>
<body>

<div class="topnav">
  <a href="index15.php">ClientLogin</a>
  <a href="admin15.php">EmpRegister</a>
  <a href="about.php">About</a>
</div>

<div style="padding-left:40px">

  <h1 style="color:white">BUG TRACKING SYSTEM</h1>
</div>


</body>
</html>
